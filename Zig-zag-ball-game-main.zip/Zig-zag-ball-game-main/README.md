download the zip file and extract the zip in one folder to play this game :)
